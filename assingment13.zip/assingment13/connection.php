<?php

$dsn = "mysql:host=localhost;dbname=myblog";  //data source host and db name
$username = "root";
$password = "SD0805may";

?>