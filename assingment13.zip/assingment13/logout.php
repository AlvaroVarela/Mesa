<?php 
//initialize message
$msg = "";
//check if logged in
if(isset($_COOKIE['login_okay'])){
    //test
    //echo "The cookie value is" . $_COOKIE['login_okay'] . "<br><br>";
    //set cookie to expire
    setcookie('login_okay', 'yes', time() - 3600 );//cookie set for one hour in past to expire cookie
    $msg = "You are now logged out. <a href='login.html'>Log in agin</a>";
}
else{
    $msg = "You are NOT logged in.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Login Page Check</title>

    <style>
        body {
            font-family: arial, sans-serif;
            font-size: 100%;
            background-color: floralwhite;
            padding: 20px;            
        }

        h1 {
            font-size: 1.8em;
        }


        .flexcontainer {
            width: 500px;
            margin: 50px 0;
            list-style-type: none;
            padding: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;           
        }

        .flexcontainer li {
            width: 120px;
            padding: 20px;
            text-align: center;
            background-color: #ccc;            
            border: 1px solid #000;

        }
        
        .flexcontainer a {
            text-decoration: none;
            color: #000;
            font-size: 1.2em;
            display: block;
            cursor: pointer;
        }


    </style>
</head>

<body>
        <header>
            <h1>Our Blog</h1>
        </header>
        <p> <?php echo $msg; ?> </p>
</body>
</html>