<?php
//initialize variable
$msg = "";

//retrieve form values

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST["blogtitle"];
    $title = addslashes($title);
    $entry = $_POST["blogentry"];
    $entry = addslashes($entry);
}

else {
    exit("There is a problem");
}

//Conection string
include 'connection.php';


//check connection AND INSERT using try/catch statement
try  {
    $conn = new PDO($dsn, $username, $password);
   
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
   
    echo "Connection is successful<br><br>\n\r";

    //create SQL query
    $sql = "INSERT INTO my_table (Title, Entry) VALUES ('$title', '$entry')";


    //execute the statement - we do not use 'query()' because no record are returned
    $conn->exec($sql);
    echo "The record was sucessfully entered";
    $msg = "Thank you for submitting a blog post! You may see your entry <a href='blog_home.php'>Here</a>.</p>";
}

catch (PDOException $e) {
      $error_message = $e->getMessage();
   echo "An error occurred: $error_message" ;
} // end try catch
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Inserting Data into the Database</title>
</head>
<body>
    <header>
        <h1>Blog Post Results</h1>
    </header>
    <p><?php echo $msg; ?></p>
</body>
</html>