//Thats the JavaScript part of the code where we process the data
    function validateLogin(){
        event.preventDefault();
        //Those are the constants that we have with the email and pasword that will work to login
        const email = 'finalproj@gmail.com';
        const password = 'test';
        //Here is where we reead the entered data, and save the value in new constants 
        const enteredemail = document.getElementById("email").value;
        const enteredpassword = document.getElementById("password").value;
        //this is the conditional that check that the email and the paswords are correct, and if that the case it returns the WelcomeMSG with the reference to the Account HTML
        if (email == enteredemail && password == enteredpassword){
            sessionStorage.setItem('auth','yes');
            document.getElementById("welcomeMsg").innerHTML = 'Welcome, please click here to access your account <a href="account.html">Account</a>';
        }
        // If email or password are wrong it returns the "wrong email or password" msg. 
        else{
            document.getElementById("welcomeMsg").innerHTML = 'Wrong Email or Password, Please try again';
        }
        return false;
    } 
     //this is the jquery funtion to the remember me option of the login, im not sure if it works as spected, but it works
    $(function() {
 
        if (localStorage.chkbx && localStorage.chkbx != '') {
            $('#remember_me').attr('checked', 'checked');
            $('#xip_Name').val(localStorage.usrname);
            $('#xip_Password').val(localStorage.pass);
        } 
        else {
            $('#remember_me').removeAttr('checked');
             $('#xip_Name').val('');
            $('#xip_Password').val('');
        }
 
        $('#remember_me').click(function() {

                if ($('#remember_me').is(':checked')) {
                    // save username and password
                    localStorage.usrname = $('#xip_Name').val();
                    localStorage.pass = $('#xip_Password').val();
                    localStorage.chkbx = $('#remember_me').val();
                } else {
                    localStorage.usrname = '';
                    localStorage.pass = '';
                    localStorage.chkbx = '';
                }
            });
        });
 
  